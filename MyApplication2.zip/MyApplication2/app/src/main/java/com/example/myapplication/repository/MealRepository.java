package com.example.myapplication.repository;

import android.util.Log;

import androidx.lifecycle.MutableLiveData;

import com.example.myapplication.models.MealModel;
import com.example.myapplication.retrofit.FoodAppApi;
import com.example.myapplication.retrofit.RetrofitInstance;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MealRepository {
    private FoodAppApi api;

    public MealRepository() {
        api = RetrofitInstance.getRetrofit().create(FoodAppApi.class);
    }
    public MutableLiveData<MealModel> getMeals(int idcate){
        MutableLiveData<MealModel> data = new MutableLiveData<>();
        api.getMeals(idcate).enqueue(new Callback<MealModel>() {
            @Override
            public void onResponse(Call<MealModel> call, Response<MealModel> response) {
                data.setValue(response.body());
            }
            @Override
            public void onFailure(Call<MealModel> call, Throwable throwable) {
                Log.d("Logg", throwable.getMessage());
                data.setValue(null);
            }
        });
        return data;
    }
}
