package com.example.myapplication.Utils;

import com.example.myapplication.models.Cart;

import java.util.ArrayList;
import java.util.List;

public class Utils {
    public static List<Cart> cartList = new ArrayList<>();
}
