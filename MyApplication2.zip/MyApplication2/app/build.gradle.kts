plugins {
    id("com.android.application")
//    id("org.jetbrains.kotlin.plugin.serialization") version "1.8.10"
}

android {
    namespace = "com.example.myapplication"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.myapplication"
        minSdk = 30
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    buildFeatures {
        dataBinding = true
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }
    packagingOptions {
        exclude ("META-INF/DEPENDENCIES")
    }

}

dependencies {

    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.11.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test.ext:junit:1.1.5")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.5.1")

    implementation ("com.intuit.sdp:sdp-android:1.1.0")
    implementation ("com.intuit.ssp:ssp-android:1.1.0")
    implementation ("com.airbnb.android:lottie:5.2.0")

    implementation ("androidx.recyclerview:recyclerview:1.0.0")
    implementation ("com.google.android.material:material:1.0.0")
    




    // Retrofit
    implementation(files("libs/retrofit-2.9.0.jar"))
    implementation (files("libs/converter-gson-2.9.0.jar"))
    implementation (files("libs/okhttp-3.14.9.jar"))
    implementation (files("libs/gson-2.9.0.jar"))



    // This block defines the ViewModel version

    val lifecycle_version = "2.6.1"
// Use implementation for dependencies block in Kotlin
    implementation("androidx.lifecycle:lifecycle-viewmodel:$lifecycle_version")
    implementation("androidx.lifecycle:lifecycle-livedata:2.6.1@aar")
    //
    implementation("com.github.bumptech.glide:glide:4.13.2")
    annotationProcessor("com.github.bumptech.glide:compiler:4.13.2")
    //

    implementation ("org.apache.httpcomponents:httpclient:4.5.14")

    implementation ("de.hdodenhof:circleimageview:3.1.0")

    implementation ("io.github.pilgr:paperdb:2.7.2")

}




