package com.example.myapplication.listener;

import com.example.myapplication.models.Category;

public interface CategoryListener {
    void onCategoryClick(Category category);
}
