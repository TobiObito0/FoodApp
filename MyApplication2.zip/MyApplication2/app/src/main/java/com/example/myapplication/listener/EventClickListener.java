package com.example.myapplication.listener;

import com.example.myapplication.models.Meals;

public interface EventClickListener {
    void onPopularClick(Meals meals);
}
